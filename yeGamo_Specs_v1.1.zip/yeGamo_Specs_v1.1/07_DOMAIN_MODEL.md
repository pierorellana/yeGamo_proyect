# Modelo de dominio

## Entidades principales

### User
Identidad, preferencias, consentimiento, reputacion interna y configuracion de notificaciones.

### Place
Lugar guardado por usuario: coordenada, etiqueta y metadatos de geocodificacion.

### CommuteProfile
Viaje recurrente con origen, destino, dias, hora objetivo, margen y preferencias.

### TransitAgency
Operador/agencia cuando la fuente lo identifica.

### TransitRoute
Representacion canonica de una ruta. Puede tener multiples referencias por proveedor.

### TransitStop
Parada/estacion canonica con geometria y referencias externas.

### ProviderReference
Relaciona entidad canonica con `provider + external_id` y reglas de licencia.

### JourneyPlan
Solicitud de planificacion con origen, destino, modo temporal y preferencias.

### JourneyOption
Alternativa normalizada compuesta por Legs.

### JourneyLeg
Tramo WALK/TRANSIT; contiene tiempos, geometria, parada de origen/destino y detalles de linea.

### ActiveJourney
Instancia ejecutada de una opcion con ETA actualizada y estado.

### RouteObservation
Dato observado util para calibracion: duracion, espera, retraso, fuente y calidad.

### RouteMetric
Agregado por ruta, direccion, dia/franja: mediana, percentiles, dispersion y yeGamo Score.

### CommunityReport
Incidencia geolocalizada con tipo, vigencia, evidencia opcional, estado y score de confianza.

### NotificationIntent
Evento de negocio que debe convertirse en push/local notification: salida, bajada, incidente, cambio de ETA.

## Value Objects
- GeoPoint
- TimeWindow
- ETAEstimate `{min, expected, max, confidence}`
- TravelPreference
- ProviderFreshness
- ReliabilityScore

## Estados de ActiveJourney
`PLANNED -> ACTIVE -> COMPLETED | CANCELLED | ABANDONED`.

## Estados de CommunityReport
`ACTIVE -> CONFIRMED -> RESOLVED | EXPIRED | REJECTED`.
