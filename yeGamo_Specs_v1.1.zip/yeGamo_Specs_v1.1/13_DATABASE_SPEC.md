# Especificacion de datos PostgreSQL/PostGIS

## Motor
PostgreSQL con PostGIS. UUID como PK. `timestamptz` para eventos. `geography(Point,4326)` para ubicaciones y `geometry(LineString,4326)` para shapes cuando corresponda.

## Tablas de negocio
- `users`
- `user_preferences`
- `saved_places`
- `commute_profiles`
- `journey_plans`
- `journey_options`
- `active_journeys`
- `journey_events`
- `notifications`
- `leave_alerts`
- `notification_preferences`
- `community_reports`
- `report_confirmations`
- `route_observations`
- `route_metrics`

## Catalogo de transporte
- `transit_agencies`
- `transit_routes`
- `transit_stops`
- `route_stops`
- `provider_references`
- `transit_feed_versions`

## Regla de licencia
`provider_references.storage_policy` define `PERSIST_ALLOWED`, `EPHEMERAL_ONLY` o `METADATA_ONLY`. Jobs de ingesta deben respetarlo.

## Indices
- GiST en `transit_stops.location`, `saved_places.location`, `community_reports.location`.
- B-tree en external IDs, route IDs, timestamps, status.
- Indices compuestos en route metrics por `(route_id, direction, day_of_week, time_bucket)`.

## Retencion
- Location samples detallados: minimizados y retencion corta (ej. 30 dias) solo con consentimiento.
- Metricas agregadas anonimizadas: retencion larga.
- Datos de proveedor: segun licencia/TTL.

## Estado local invitado
Los guardados y preferencias de un invitado pueden vivir exclusivamente en almacenamiento local cifrado/seguro cuando aplique. Al crear cuenta, la migracion a servidor debe ser explicita e idempotente.
