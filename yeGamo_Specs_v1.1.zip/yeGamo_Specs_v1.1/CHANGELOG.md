# Changelog

## 1.1 - 2026-10-02
- Rebranding RutaYa -> yeGamo.
- Alineacion funcional con prototipo navegable.
- 17 pantallas formalizadas.
- 9 estados UX formalizados.
- Rutinas y Avisos integrados al alcance MVP.
- API ampliada con alerts, notifications y preferences.
- Trazabilidad pantalla -> RF.
- Baseline de sistema visual y marca.
- Aclaracion de datos mock y de la referencia "Metrovia GTFS".
- Criterios de testing actualizados.

## 1.0 - 2026-09-19
- Baseline inicial de producto, negocio, integracion y arquitectura.
