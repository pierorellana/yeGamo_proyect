# yeGamo · Prototipo iOS — paquete completo

Movilidad urbana para Guayaquil: **cuándo salir, qué tomar y cuándo llegas**.
Todos los horarios, lugares, líneas, fiabilidades y fuentes son **datos de demostración**.

## Cómo abrirlo

1. **`prototipo/yeGamo-prototipo.html`** es el ejecutable. Haz doble clic y se abre en Chrome, Safari, Edge o Firefox, sin servidor ni instalación.
   - El panel lateral sirve para saltar a cualquiera de las 19 pantallas y a cualquiera de los 7 estados de datos, para reiniciar desde el splash y para alternar entre ajustar a la ventana o ver a tamaño real.
   - También acepta parámetros de URL, por ejemplo `yeGamo-prototipo.html?start=alts&dstate=error`.
2. **`laminas/`** contiene las 9 láminas del lienzo de diseño (identidad, sistema, flujos, estados, panel, mapa de flujos) como páginas sueltas que se pueden abrir con doble clic.
3. **`capturas/`** tiene PNG @2x de cada pantalla y estado, PNG de cada lámina y videos MP4 de las animaciones.

Sin internet funciona igual. Sin la fuente Geist, la interfaz usa la fuente del sistema (SF Pro en Apple).

## Estructura

| Carpeta | Contenido |
|---|---|
| `prototipo/` | Ejecutable HTML autónomo (todo en un archivo). |
| `laminas/` | Láminas del lienzo de diseño en HTML autónomo. |
| `capturas/pantallas/` | 01–23 pantallas + E1–E8 estados, PNG 780 × 1688 (@2x). |
| `capturas/laminas/` | Render PNG de cada lámina. |
| `capturas/videos/` | `splash.mp4`, `onboarding.mp4`, `flujo-completo.mp4`, `panel-y-mapa.mp4`. |
| `assets/logo/simbolo/` | Símbolo G-recorrido: claro, oscuro, mono moss, mono blanco, versión pequeña (29 pt). SVG + PNG 512/256/64. |
| `assets/logo/logotipo/` | Palabra «yeGamo» en curvas vectoriales: moss, blanco y acento en la G. SVG + PNG @3x. |
| `assets/logo/lockup/` | Símbolo + logotipo horizontal, claro y oscuro. |
| `assets/app-icon/` | Ícono de app claro (principal), oscuro y tintado. Máster 1024 (sangrado completo, iOS aplica la máscara), versión redondeada y PNG en todos los tamaños iOS (1024 → 20). |
| `assets/iconos/` | 43 iconos SVG (24 × 24, trazo 1,8, `currentColor`), `iconos.json` y `catalogo-iconos.html`. |
| `assets/ilustraciones/` | Ilustraciones de estados vacíos y de error, y la mini-ruta del onboarding. |
| `assets/mapa/` | Vehículo bus y etiquetas «en vivo» y «estimado». |
| `assets/colores-y-tokens/` | `tokens.json`, `tokens.css`, `yg_tokens.dart` (Flutter) y `paleta.html`. |
| `assets/animaciones/` | `keyframes.css` (los 55 keyframes del prototipo) y `LEEME-animaciones.md`. |
| `fuente-editable/` | Archivos originales del lienzo (`*.dc.html` + `canvas.json`) y el runtime usado para el ejecutable. |

## Identidad

- **Símbolo:** la G es un recorrido. Arranca en un anillo de origen (arriba a la derecha), da la vuelta y termina en un punto de destino. Trazo 10/100, terminaciones redondeadas.
- **Logotipo:** «yeGamo» con la G mayúscula. En la app se compone con SF Pro Display Semibold, tracking −4 %. La versión vectorial de `logotipo/` está en curvas, con Inter Display SemiBold como equivalente abierto.
- **Splash:** solo tipografía. Las letras suben de a una, se dibuja una línea de trayecto de origen a destino y aparece «Sal a tiempo.» (3,5 s, se salta con un toque).

## Paleta «Bosque claro»

| Token | Hex | Uso |
|---|---|---|
| Moss | `#2C3424` | Botón principal, texto fuerte, ruta elegida |
| Cypress | `#4C583E` | Acción «ir», en vivo, acentos |
| Olive | `#768064` | Caminata, apoyo del fondo |
| Cedar | `#959581` | Estimado, rutas alternativas |
| Aloe | `#DADED8` | Rellenos suaves |
| Clay | `#9C4F3A` | Solo errores y sin cobertura |

**Fondo:** blanco dominante con velo oliva de 13–17 % (ver `tokens.css`, variable `--yg-bg`).

## Sistema de componentes

- **Botones:** 56 (entrada), 48 (estándar) y 36 (en línea), siempre en forma de píldora.
- **Botones de icono:** 44, o 36 en la versión pequeña.
- **Tarjetas:** radio 20, relleno 16, borde `#E6E8E1` con sombra suave. Estructura: tile de ícono 36 + 12 + contenido + acción.
- **Filas de lista:** 56 de alto, con separador alineado al texto (64).
- **Espaciado:** margen lateral 16, separación entre secciones 24, etiqueta de sección 24/12.
- **Panel inferior:** tres alturas (mínimo, intermedio, expandido) con spring 0,55 s. La cámara del mapa se ajusta al espacio visible y deja libre la columna de controles.
- **Avisos temporales y banners:** debajo de la barra superior (y = 108), nunca encima de ella.
- **Modales:** pie fijo con la acción principal (48) y la secundaria de texto (44).

## Flujos

- **Arranque:** Splash → Onboarding (3 páginas, deslizables) → Permisos → Inicio.
- **Principal:** Inicio → Buscar → **1** Planificar → Cargando → **2** Alternativas → **3** Cuándo salir → (Paso a paso) → Viaje activo → Alerta de bajada → Llegada → Inicio.
- **Atajos:** «Ver mi salida», un aviso o una rutina llevan directo a Cuándo salir.
- **Pestañas:** Inicio, Guardados, Rutinas, Avisos. Ajustes se abre desde el avatar.
- **Estados:** correcto, cargando, vacío, error, sin conexión, desactualizado, parcial, sin permiso y sin cobertura.

## Notas para Flutter

`yg_tokens.dart` trae colores, espaciado, radios, tamaños, curvas y estilos de texto. Equivalencias sugeridas:

| Prototipo | Flutter |
|---|---|
| Panel inferior | `DraggableScrollableSheet` + `SpringSimulation` |
| Mapa | `GoogleMap` o `flutter_map` con estilo claro, `padding` = altura del panel y columna de controles |
| Vehículos | `AnimatedPositioned` / interpolación de 1 s por muestra |
| Splash | `AnimationController` de 3,5 s con `Interval` por letra |
