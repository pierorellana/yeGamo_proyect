# Animaciones de yeGamo

Todos los keyframes están en `keyframes.css`, agrupados por origen (Main = interfaz, MapLayer = mapa). Con «Reducir movimiento» activo se apagan la cámara 3D, los vuelos y los pulsos, y todo pasa a fundidos de 120 ms.

## Curvas base

| Nombre | Curva | Uso |
|---|---|---|
| Spring de panel | `cubic-bezier(.3,1.16,.4,1)` · 0,55 s | Panel inferior, controles del mapa |
| Salida suave | `cubic-bezier(.22,1,.36,1)` · 0,5–0,7 s | Entradas, onboarding, pantallas |
| Toque | `cubic-bezier(.34,1.56,.64,1)` · 0,3 s, escala 0,96 | Botones, tarjetas, chips |
| Cámara | `cubic-bezier(.2,.85,.25,1)` · 1,3 s | Encuadre del mapa |
| Seguimiento | lineal 1 s por muestra | Buses y usuario en el mapa |

## Secuencias

- **Splash (3,5 s):**
  - Letras de «yeGamo» con `splL`, 0,9 s, escalonadas 50 ms desde 0,25 s.
  - El origen aparece con `splPop` a 0,9 s.
  - El trayecto se dibuja con `splRl` desde 1,0 s.
  - El lema entra con `splT` a 1,2 s.
  - El destino aparece con `splPop` a 2,4 s.
- **Onboarding:**
  - El carril se desliza 0,7 s.
  - Página 1: tarjetas en abanico (`fanIn`), manchas (`blobIn`, `blobBr`) y puntos flotantes (`dotIn`, `dotFl`).
  - Página 2: la ruta se dibuja (`mdraw`), aparecen los pines (`pinIn`) y las tarjetas (`pcdIn`) y el bus recorre la ruta (`obus`).
  - Página 3: entra la tarjeta (`nbIn`), se traza la curva (`mdraw`), crece la banda (`bandIn`) y aparece la etiqueta (`tagIn`).
  - Textos con `obT`.
- **Pantallas:**
  - Navegación con `inPush`, `inBack`, `inUp` e `inFade` (3D leve).
  - Listas escalonadas con `rise`.
  - Panel inferior con `sheetIn`.
- **Datos:**
  - Pulso en vivo con `lv`.
  - Pasos de carga con `spin` y `okIn`.
  - Medidor de fiabilidad con `gIn`.
  - Ventana de llegada con `grow`.
  - Dígitos de la hora de salida con `fd` (volteo).
- **Viaje:**
  - Alerta de bajada con `goIn`, `shake`, `bp` y `bring` (campana).
  - Llegada con `coin` y `mdraw` (check).
- **Feedback:** aviso temporal con `toastIn3d`. Check del aviso con `ckd`.

Los videos de `capturas/videos/` muestran cada secuencia en movimiento.
