// yeGamo · tokens de diseño para Flutter (generado del prototipo)
import 'package:flutter/material.dart';

class YgColors {
  static const moss = Color(0xFF2C3424);
  static const cypress = Color(0xFF4C583E);
  static const olive = Color(0xFF768064);
  static const cedar = Color(0xFF959581);
  static const aloe = Color(0xFFDADED8);
  static const clay = Color(0xFF9C4F3A);
  static const text = Color(0xFF1E2419);
  static const text2 = Color(0xFF5B624F);
  static const text3 = Color(0xFF6E7362);
  static const surface = Color(0xFFFFFFFF);
  static const fill = Color(0xFFEEF0EA);
  static const fill2 = Color(0xFFF4F6F0);
  static const border = Color(0xFFE6E8E1);
  static const divider = Color(0xFFEEF0EA);
  static const handle = Color(0xFFD3D7CC);
  static const mapBase = Color(0xFFEEF0E8);
  static const mapBlock = Color(0xFFE3E6DD);
  static const mapRoad = Color(0xFFFFFFFF);
  static const mapWater = Color(0xFFC8D3CC);
  static const mapPark = Color(0xFFDCE3D3);
  static const routeSelected = Color(0xFF2C3424);
  static const routeAlt = Color(0xFF959581);
  static const walkDots = Color(0xFF768064);
  static const liveBus = Color(0xFF4C583E);
  static const estimatedBus = Color(0xFFFFFFFF + BORDE PUNTEADO #959581);
}

class YgSpace { static const x05 = 4.0, x1 = 8.0, x15 = 12.0, x2 = 16.0, x3 = 24.0, x4 = 32.0; }
class YgRadius { static const chip = 16.0, tile = 10.0, card = 20.0, banner = 16.0, sheet = 32.0; }
class YgSize { static const buttonLg = 56.0, buttonMd = 48.0, buttonSm = 36.0, iconButton = 44.0, tile = 36.0, listRow = 56.0, chip = 32.0; }

class YgMotion {
  static const sheet = Duration(milliseconds: 550);
  static const enter = Duration(milliseconds: 500);
  static const tap = Duration(milliseconds: 300);
  static const camera = Duration(milliseconds: 1300);
  static const vehicleTick = Duration(seconds: 1);
  static const spring = Cubic(.3, 1.16, .4, 1);
  static const easeOut = Cubic(.22, 1, .36, 1);
  static const tapCurve = Cubic(.34, 1.56, .64, 1);
  static const cameraCurve = Cubic(.2, .85, .25, 1);
}

/// Fondo: blanco dominante con velo oliva (13–17 %).
const ygBackground = BoxDecoration(
  gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
    colors: [Color(0xFFFFFFFF), Color(0xFFFFFFFF), Color(0xFFF4F6F0)], stops: [0, .42, 1]),
);
const ygBackgroundGlowTopRight = RadialGradient(center: Alignment.topRight, radius: 1.2,
  colors: [Color(0x21959581), Color(0x00959581)], stops: [0, .58]);
const ygBackgroundGlowBottomLeft = RadialGradient(center: Alignment.bottomLeft, radius: 1.3,
  colors: [Color(0x2B768064), Color(0x00768064)], stops: [0, .62]);

class YgText {
  static const heroTime = TextStyle(fontSize: 64, fontWeight: FontWeight.w600, letterSpacing: -2.56, fontFeatures: [FontFeature.tabularFigures()]);
  static const summaryTime = TextStyle(fontSize: 48, fontWeight: FontWeight.w600, letterSpacing: -1.92, fontFeatures: [FontFeature.tabularFigures()]);
  static const largeTitle = TextStyle(fontSize: 28, fontWeight: FontWeight.w700, letterSpacing: -.7);
  static const title2 = TextStyle(fontSize: 20, fontWeight: FontWeight.w600, letterSpacing: -.44);
  static const title = TextStyle(fontSize: 17, fontWeight: FontWeight.w600, letterSpacing: -.34);
  static const body = TextStyle(fontSize: 15, fontWeight: FontWeight.w400, letterSpacing: -.15);
  static const bodyStrong = TextStyle(fontSize: 15, fontWeight: FontWeight.w600, letterSpacing: -.15);
  static const secondary = TextStyle(fontSize: 13, fontWeight: FontWeight.w400);
  static const meta = TextStyle(fontSize: 12, fontWeight: FontWeight.w400);
  static const overline = TextStyle(fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: .66);
}
