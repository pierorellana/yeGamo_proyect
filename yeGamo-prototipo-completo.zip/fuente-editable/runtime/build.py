import json, re, os, sys
SRC=os.environ.get('YG_SRC','../lienzo')
RT=open('runtime.js').read()
def files_for(name, acc=None):
    acc = acc if acc is not None else {}
    if name in acc: return acc
    t=open(f'{SRC}/{name}.dc.html').read(); acc[name]=t
    for m in set(re.findall(r'<dc-import name="([^"]+)"',t)): files_for(m,acc)
    return acc
def embed(name):
    js=json.dumps(files_for(name),ensure_ascii=False).replace('</','<\\/').replace('<!--','<\\!--')
    return js
FONT='<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&family=Geist+Mono:wght@500&display=swap" rel="stylesheet">'
ICON='<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22%3E%3Crect width=%22100%22 height=%22100%22 rx=%2224%22 fill=%22%23FFFFFF%22/%3E%3Cpath d=%22M76 24H40Q24 24 24 40V60Q24 76 40 76H60Q76 76 76 60V52H54%22 fill=%22none%22 stroke=%22%234C583E%22 stroke-width=%2210%22 stroke-linecap=%22round%22 stroke-linejoin=%22round%22/%3E%3Ccircle cx=%2276%22 cy=%2224%22 r=%228.5%22 fill=%22%23FFFFFF%22 stroke=%22%232C3424%22 stroke-width=%224%22/%3E%3Ccircle cx=%2254%22 cy=%2252%22 r=%228%22 fill=%22%232C3424%22/%3E%3C/svg%3E">'

def prototype():
    return f'''<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>yeGamo · Prototipo iOS</title>{ICON}{FONT}
<style>
:root{{--bg:#FFFFFF;--ink:#1E2419;--mut:#5B624F;--line:#E6E8E1;--moss:#2C3424;--cy:#4C583E}}
*{{box-sizing:border-box}}
html,body{{margin:0;height:100%}}
body{{min-height:100%;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Geist",system-ui,sans-serif;-webkit-font-smoothing:antialiased;background:radial-gradient(90% 60% at 100% 0%,rgba(149,149,129,.16),rgba(149,149,129,0) 60%),radial-gradient(90% 70% at 0% 100%,rgba(118,128,100,.2),rgba(118,128,100,0) 62%),linear-gradient(180deg,#FFFFFF,#F2F4EE)}}
.wrap{{min-height:100vh;display:flex;align-items:center;justify-content:center;gap:56px;padding:32px 24px}}
.dev{{width:var(--w);height:var(--h);flex:none;position:relative}}
.frame{{position:absolute;left:0;top:0;width:414px;height:868px;padding:12px;border-radius:56px;background:#1E2419;box-shadow:0 0 0 1px rgba(255,255,255,.08) inset,0 40px 80px rgba(44,52,36,.28),0 8px 20px rgba(44,52,36,.18);transform-origin:0 0;transform:scale(var(--s))}}
.screen{{width:390px;height:844px;border-radius:44px;overflow:hidden;position:relative;background:#FFFFFF;transform:translateZ(0)}}
.island{{position:absolute;left:50%;top:23px;width:120px;height:34px;margin-left:-60px;border-radius:17px;background:#000;z-index:200;pointer-events:none}}
.sbar{{position:absolute;left:0;right:0;top:12px;height:47px;padding:0 34px 0 46px;display:flex;align-items:center;justify-content:space-between;font-size:16px;font-weight:600;color:#1E2419;z-index:199;pointer-events:none;letter-spacing:-.01em}}
.sbar i{{display:inline-block;width:25px;height:12px;border-radius:4px;box-shadow:inset 0 0 0 1.2px rgba(30,36,25,.45);position:relative;margin-left:6px;vertical-align:-1px}}
.sbar i::after{{content:"";position:absolute;left:2px;top:2px;bottom:2px;width:17px;border-radius:2px;background:#1E2419}}
.hbar{{position:absolute;left:50%;bottom:20px;width:134px;height:5px;margin-left:-67px;border-radius:3px;background:#1E2419;z-index:199;pointer-events:none;opacity:.85}}
.side{{width:300px;flex:none;display:flex;flex-direction:column;gap:20px}}
.brand{{display:flex;align-items:center;gap:10px;font-size:22px;font-weight:650;letter-spacing:-.04em;color:var(--moss)}}
.lead{{margin:0;font-size:14px;line-height:1.55;color:var(--mut)}}
.grp{{display:flex;flex-direction:column;gap:8px}}
.lbl{{font-size:11px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:#6E7362}}
select,button.b{{height:44px;border-radius:12px;border:0;font:inherit;font-size:14px;color:var(--ink);background:#FFFFFF;box-shadow:inset 0 0 0 1px var(--line),0 2px 6px rgba(44,52,36,.05);padding:0 12px}}
select{{appearance:none;background-image:linear-gradient(45deg,transparent 50%,#5B624F 50%),linear-gradient(135deg,#5B624F 50%,transparent 50%);background-position:calc(100% - 18px) 19px,calc(100% - 13px) 19px;background-size:5px 5px;background-repeat:no-repeat;cursor:pointer}}
button.b{{cursor:pointer;font-weight:600;background:var(--moss);color:#FFF;box-shadow:0 6px 16px rgba(44,52,36,.18)}}
button.b.s{{background:#EEF0EA;color:var(--moss);box-shadow:none}}
.row{{display:flex;gap:8px}}.row>*{{flex:1}}
.note{{font-size:12px;line-height:1.5;color:#6E7362;border-top:1px solid var(--line);padding-top:16px}}
.kbd{{display:inline-block;padding:1px 6px;border-radius:5px;background:#EEF0EA;font-family:ui-monospace,"Geist Mono",monospace;font-size:11px;color:var(--moss)}}
@media (max-width:820px){{.wrap{{flex-direction:column;gap:28px}}.side{{width:min(414px,100%)}}}}
@media (max-width:440px){{.frame{{border-radius:0;padding:0;background:none;box-shadow:none}}.island,.sbar,.hbar{{display:none}}.wrap{{padding:0}}}}
</style></head>
<body>
<div class="wrap">
<div class="dev" id="dev"><div class="frame" id="frame"><div class="screen" id="screen"><div class="sbar"><span>9:41</span><span>●●● <i></i></span></div><div class="island"></div><div class="hbar"></div></div></div></div>
<aside class="side">
<div class="brand"><svg width="30" height="30" viewBox="0 0 100 100" aria-hidden="true"><path d="M76 24H40Q24 24 24 40V60Q24 76 40 76H60Q76 76 76 60V52H54" fill="none" stroke="#4C583E" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/><circle cx="76" cy="24" r="8.5" fill="#FFFFFF" stroke="#2C3424" stroke-width="4"/><circle cx="54" cy="52" r="8" fill="#2C3424"/></svg>yeGamo</div>
<p class="lead">Prototipo iOS navegable para Guayaquil: cuándo salir, qué tomar y cuándo llegas. Todos los horarios, lugares y fuentes son <b>datos de demostración</b>.</p>
<div class="grp"><span class="lbl">Ir a pantalla</span><select id="scr"></select></div>
<div class="grp"><span class="lbl">Estado de datos</span><select id="ds"></select></div>
<div class="row"><button class="b" id="restart">Reiniciar desde el splash</button></div>
<div class="row"><button class="b s" id="fit">Ajustar a la ventana</button></div>
<p class="note">Arrastra el panel inferior por su asa (mínimo · intermedio · expandido). El mapa se arrastra y hace zoom con la rueda o los controles flotantes. Desliza el onboarding hacia los lados. En Ajustes puedes repetir la introducción y saltar a cualquier estado.</p>
</div>
</aside>
</div>
<script>window.DC_FILES={embed('Main')};</script>
<script>{RT}</script>
<script>
(function(){{
 var SCREENS=[['splash','01 · Splash'],['onboarding','02 · Onboarding'],['perm','03 · Permisos'],['home','04 · Inicio'],['search','05 · Buscar'],['nearby','06 · Cercano'],['planner','07 · Planificar'],['loading','08 · Cargando'],['alts','09 · Alternativas'],['depart','10 · Cuándo salir'],['steps','11 · Paso a paso'],['active','12 · Viaje activo'],['getoff','13 · Alerta de bajada'],['arrived','14 · Llegada'],['saved','15 · Guardados'],['routines','16 · Rutinas'],['notices','17 · Avisos'],['settings','18 · Ajustes'],['nocov','19 · Sin cobertura']];
 var STATES=[['ok','Correcto'],['error','Error'],['empty','Vacío'],['offline','Sin conexión'],['stale','Desactualizado'],['degraded','Parcial'],['permission','Sin permiso de ubicación']];
 var sel=document.getElementById('scr'),ds=document.getElementById('ds');
 SCREENS.forEach(function(s){{var o=document.createElement('option');o.value=s[0];o.textContent=s[1];sel.appendChild(o);}});
 STATES.forEach(function(s){{var o=document.createElement('option');o.value=s[0];o.textContent=s[1];ds.appendChild(o);}});
 var q=new URLSearchParams(location.search);
 var props={{start:q.get('start')||'splash',dstate:q.get('dstate')||'ok'}};
 sel.value=props.start;ds.value=props.dstate;
 var host=dcMount('Main',props,document.getElementById('screen'));
 var n=0;
 function go(){{n++;host.setProps({{start:sel.value,dstate:ds.value,_n:n}});}}
 sel.onchange=go;ds.onchange=go;
 document.getElementById('restart').onclick=function(){{sel.value='splash';ds.value='ok';host.el.remove();host=dcMount('Main',{{start:'splash',dstate:'ok'}},document.getElementById('screen'));}};
 var fitOn=true;
 function fit(){{var s=1;if(fitOn&&window.innerWidth>440){{s=Math.min(1,(window.innerHeight-48)/868);}}if(window.innerWidth<=440){{s=Math.min(1,window.innerWidth/390);}}
  var d=document.documentElement;d.style.setProperty('--s',s);var narrow=window.innerWidth<=440;d.style.setProperty('--w',(narrow?390:414)*s+'px');d.style.setProperty('--h',(narrow?844:868)*s+'px');}}
 document.getElementById('fit').onclick=function(){{fitOn=!fitOn;this.textContent=fitOn?'Ajustar a la ventana':'Tamaño real (1:1)';fit();}};
 window.addEventListener('resize',fit);fit();
}})();
</script>
</body></html>'''

def board(name, w, h, title):
    return f'''<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>yeGamo · {title}</title>{ICON}{FONT}
<style>html,body{{margin:0;background:#F4F6F0}}#b{{width:{w}px;height:{h}px;position:relative}}</style></head>
<body><div id="b"></div>
<script>window.DC_FILES={embed(name)};</script>
<script>{RT}</script>
<script>dcMount({json.dumps(name)},{{}},document.getElementById('b'));</script>
</body></html>'''

if __name__=='__main__':
    out=sys.argv[1]; os.makedirs(out,exist_ok=True)
    open(f'{out}/yeGamo-prototipo.html','w').write(prototype())
    cj=json.load(open(f'{SRC}/canvas.json'))
    os.makedirs(f'{out}/laminas',exist_ok=True)
    for i,fn in enumerate(cj['order'],1):
        b=cj['boards'][fn]; nm=fn.replace('.dc.html','')
        open(f'{out}/laminas/{i:02d}-{nm}.html','w').write(board(nm,b['w'],b['h'],b['title']))
    print('built')
