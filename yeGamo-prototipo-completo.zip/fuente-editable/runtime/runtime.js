/* yeGamo · runtime autónomo para los archivos .dc.html (plantillas + lógica DCLogic).
   Renderiza la plantilla con {{huecos}}, <sc-if>, <sc-for> y <dc-import>, y aplica los cambios
   al DOM por claves estables para que las animaciones CSS no se reinicien en cada actualización. */
(function () {
  'use strict';
  function DCLogic(props) { this.props = props || {}; this.state = {}; }
  DCLogic.prototype.setState = function (o, cb) {
    var s = typeof o === 'function' ? o(this.state, this.props) : o;
    this.state = Object.assign({}, this.state, s || {});
    if (this.__host) this.__host.schedule(cb); else if (cb) setTimeout(cb, 0);
  };
  window.DCLogic = DCLogic;

  var SOURCES = window.DC_FILES || {};
  var LOADED = {};
  var tplSeq = 0;

  function load(name) {
    if (LOADED[name]) return LOADED[name];
    var txt = SOURCES[name];
    if (!txt) throw new Error('Falta el componente ' + name);
    var doc = new DOMParser().parseFromString(txt, 'text/html');
    var xdc = doc.querySelector('x-dc');
    var helmet = xdc.querySelector('helmet');
    if (helmet) {
      helmet.querySelectorAll('style,link').forEach(function (n) {
        var c = document.createElement(n.tagName.toLowerCase());
        for (var i = 0; i < n.attributes.length; i++) c.setAttribute(n.attributes[i].name, n.attributes[i].value);
        c.textContent = n.textContent; c.setAttribute('data-dc', name);
        document.head.appendChild(c);
      });
      helmet.remove();
    }
    var tpl = document.createElement('template');
    tpl.innerHTML = xdc.innerHTML;
    (function tag(n) { for (var c = n.firstChild; c; c = c.nextSibling) { c.__tid = ++tplSeq; if (c.childNodes) tag(c.content || c); } })(tpl.content);
    var scEl = doc.querySelector('script[data-dc-script]');
    var Cls = new Function('DCLogic', scEl.textContent + '\nreturn Component;')(DCLogic);
    var meta = {}; try { meta = JSON.parse(scEl.getAttribute('data-props') || '{}'); } catch (e) {}
    return (LOADED[name] = { tpl: tpl, Cls: Cls, meta: meta });
  }

  function look(path, scopes) {
    var parts = path.trim().split('.');
    for (var i = 0; i < scopes.length; i++) {
      var sc = scopes[i];
      if (sc && Object.prototype.hasOwnProperty.call(sc, parts[0])) {
        var v = sc;
        for (var j = 0; j < parts.length; j++) { if (v == null) return undefined; v = v[parts[j]]; }
        return v;
      }
    }
    return undefined;
  }
  var HOLE = /\{\{([^}]+)\}\}/g, ONLY = /^\s*\{\{([^}]+)\}\}\s*$/;
  function interp(str, scopes) { return str.replace(HOLE, function (m, p) { var v = look(p, scopes); return v == null ? '' : String(v); }); }
  var EVMAP = { doubleclick: 'dblclick', change: 'input' };

  function Host(name, props) {
    this.name = name; this.props = props || {}; this.kids = {};
    this.el = document.createElement('div');
    this.el.className = 'dc-host';
    this.el.style.cssText = 'width:100%;height:100%;position:relative';
    var f = load(name);
    this.f = f;
    var defaults = {};
    Object.keys(f.meta || {}).forEach(function (k) { if (k[0] !== '$' && f.meta[k] && 'default' in f.meta[k]) defaults[k] = f.meta[k].default; });
    this.props = Object.assign(defaults, this.props);
    this.inst = new f.Cls(this.props);
    this.inst.props = this.props; this.inst.__host = this;
    this.render();
    var inst = this.inst;
    if (inst.componentDidMount) setTimeout(function () { inst.componentDidMount(); }, 0);
  }
  Host.prototype.schedule = function (cb) {
    var self = this;
    if (cb) (this.cbs || (this.cbs = [])).push(cb);
    if (this.pending) return;
    this.pending = true;
    requestAnimationFrame(function () {
      self.pending = false; self.render();
      var c = self.cbs; self.cbs = null; if (c) c.forEach(function (fn) { try { fn(); } catch (e) { console.error(e); } });
    });
  };
  Host.prototype.setProps = function (props) {
    var old = this.inst.props;
    this.props = Object.assign({}, old, props);
    this.inst.props = this.props;
    if (this.inst.componentDidUpdate) this.inst.componentDidUpdate(old);
    this.schedule();
  };
  Host.prototype.render = function () {
    var vals = this.inst.renderVals();
    this.used = {};
    var vn = this.build(this.f.tpl.content, [vals], '');
    patch(this.el, vn);
    var self = this;
    Object.keys(this.kids).forEach(function (k) { if (!self.used[k]) { var h = self.kids[k]; if (h.inst.componentWillUnmount) h.inst.componentWillUnmount(); delete self.kids[k]; } });
  };
  Host.prototype.build = function (src, scopes, kp) {
    var out = [];
    for (var n = src.firstChild; n; n = n.nextSibling) {
      var key = kp + '/' + n.__tid;
      if (n.nodeType === 3) { out.push({ text: interp(n.textContent, scopes), k: key }); continue; }
      if (n.nodeType !== 1) continue;
      var tag = n.localName;
      if (tag === 'sc-if') {
        var v = look(n.getAttribute('value').replace(/[{}]/g, ''), scopes);
        if (v) out.push.apply(out, this.build(n, scopes, key));
        continue;
      }
      if (tag === 'sc-for') {
        var list = look(n.getAttribute('list').replace(/[{}]/g, ''), scopes) || [];
        var as = n.getAttribute('as');
        for (var i = 0; i < list.length; i++) { var sc = {}; sc[as] = list[i]; out.push.apply(out, this.build(n, [sc].concat(scopes), key + '#' + i)); }
        continue;
      }
      if (tag === 'dc-import') {
        var nm = n.getAttribute('name'), props = {};
        for (var a = 0; a < n.attributes.length; a++) {
          var at = n.attributes[a];
          if (at.name === 'name' || at.name.indexOf('hint') === 0) continue;
          var m = at.value.match(ONLY);
          props[at.name] = m ? look(m[1], scopes) : interp(at.value, scopes);
        }
        var kid = this.kids[key];
        if (!kid) kid = this.kids[key] = new Host(nm, props); else kid.setProps(props);
        this.used[key] = 1;
        out.push({ host: kid, k: key });
        continue;
      }
      var vn = { t: tag, ns: n.namespaceURI, a: {}, on: {}, k: key, c: null };
      for (var b = 0; b < n.attributes.length; b++) {
        var at2 = n.attributes[b], mm = at2.value.match(ONLY);
        if (/^on[A-Z]/.test(at2.name) || (/^on[a-z]+$/.test(at2.name) && mm)) {
          var fn = mm && look(mm[1], scopes);
          var ev = at2.name.slice(2).toLowerCase(); ev = EVMAP[ev] || ev;
          if (ev === 'focus') ev = 'focusin';
          if (typeof fn === 'function') vn.on[ev] = fn;
          continue;
        }
        vn.a[at2.name] = interp(at2.value, scopes);
      }
      vn.c = this.build(n.content || n, scopes, key);
      out.push(vn);
    }
    return out;
  };

  function dispatch(e) { var h = this.__on && this.__on[e.type]; if (h) return h.call(this, e); }
  function create(v) {
    if (v.host) return v.host.el;
    if ('text' in v) { var t = document.createTextNode(v.text); t.__k = v.k; return t; }
    var el = document.createElementNS(v.ns || 'http://www.w3.org/1999/xhtml', v.t);
    el.__k = v.k; el.__on = {}; el.__ev = {};
    update(el, v);
    return el;
  }
  function update(el, v) {
    var old = el.__a || {}, na = v.a, k;
    for (k in na) {
      if (old[k] !== na[k]) {
        if (k === 'value' && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) { if (document.activeElement !== el) el.value = na[k]; el.setAttribute(k, na[k]); }
        else el.setAttribute(k, na[k]);
      }
    }
    for (k in old) if (!(k in na)) el.removeAttribute(k);
    el.__a = na;
    el.__on = v.on;
    for (k in v.on) if (!el.__ev[k]) { el.addEventListener(k, dispatch, k === 'wheel' ? { passive: false } : false); el.__ev[k] = 1; }
    patch(el, v.c);
  }
  function compatible(node, v) {
    if (!node) return false;
    if (v.host) return node === v.host.el;
    if ('text' in v) return node.nodeType === 3;
    return node.nodeType === 1 && node.localName === v.t && node.__k === v.k;
  }
  function patch(parent, vlist) {
    var byKey = {};
    for (var c = parent.firstChild; c; c = c.nextSibling) if (c.__k) byKey[c.__k] = c; else if (c.className === 'dc-host') byKey['host:' + (c.__hk || '')] = c;
    var ref = parent.firstChild;
    var keep = [];
    for (var i = 0; i < vlist.length; i++) {
      var v = vlist[i];
      var node = v.host ? v.host.el : byKey[v.k];
      if (node && !compatible(node, v)) node = null;
      if (node) {
        if ('text' in v) { if (node.nodeValue !== v.text) node.nodeValue = v.text; }
        else if (!v.host) update(node, v);
      } else node = create(v);
      if (node !== ref) parent.insertBefore(node, ref); else ref = ref.nextSibling;
      keep.push(node);
    }
    while (ref) { var nx = ref.nextSibling; parent.removeChild(ref); ref = nx; }
  }

  window.dcMount = function (name, props, target) {
    var h = new Host(name, props);
    target.appendChild(h.el);
    return h;
  };
})();
