# Fuente editable

- `lienzo/` — archivos originales del lienzo de diseño: `Main.dc.html` (prototipo), `MapLayer.dc.html` (mapa), láminas y `canvas.json` (posiciones y orden).
  Cada `.dc.html` tiene una plantilla con huecos `{{...}}`, `<sc-if>`, `<sc-for>`, `<dc-import>`, estilos en `<helmet>` y la lógica en `class Component extends DCLogic`.
- `runtime/runtime.js` — runtime autónomo que interpreta esos archivos en cualquier navegador (usado por los HTML de `prototipo/` y `laminas/`).
- `runtime/build.py` — regenera los HTML autónomos: `python3 build.py salida` desde la carpeta `runtime/` (lee `../lienzo`; o define `YG_SRC`).
